#include "stdafx.h"
#include "julia.h"


#define RENDERSTEPS			50
#define RENDERINCREMENT		5

double gACorner		= FULLVIEW_ACORNER;
double gBCorner		= FULLVIEW_BCORNER;
double gSide		= FULLVIEW_SIDE;

int gZoomFactor		= 2;
int gZoomDir		= 1;
BOOL gStop			= FALSE;

void Plot(CDC *pDC, int nX, int nY, UINT nPixelWidth, UINT nPixelHeight, COLORREF rgbColor);


void JuliaRender(CWnd *pWnd, double dACorner, double dBCorner, double dSide)
{
	gStop = FALSE;

	const int nMaxIter = 100;

	CRect rectClient;
	double dAc, dBc, dAz, dAz2, dBz, dBz2;
	double dGapH, dGapL;
	double dSize;
	UINT nCount;
	UINT nAcross, nDown;
	UINT nHRes, nVRes;

	pWnd->GetClientRect(&rectClient);
	nHRes = rectClient.Width();
	nVRes = rectClient.Height();

	CDC *pDC = pWnd->GetDC();

	// render in steps, with increasingly finer resolution
	// this gives the user an overview of the image as it renders
	for (int nRenderStep = RENDERSTEPS; nRenderStep >= 0; nRenderStep-=RENDERINCREMENT)
	{
		nHRes = (rectClient.right - rectClient.left) / (float)(nRenderStep ? nRenderStep : 1 /* avoid divide by 0 */ );
		nVRes = (rectClient.bottom - rectClient.top) / (float)(nRenderStep ? nRenderStep : 1 /* avoid divide by 0 */ );

		dGapH = dSide / nVRes;
		dGapL = dSide / nHRes;

		UINT nPixelWidth = (float)(rectClient.right - rectClient.left) / nHRes;
		UINT nPixelHeight = (float)(rectClient.bottom - rectClient.top) / nVRes;

		for (nDown = 0; nDown < nVRes; ++nDown)
		{
			for (nAcross = 0; nAcross < nHRes; ++nAcross)
			{
				dBc = (nDown * dGapH) + dBCorner;
				dAc = (nAcross * dGapL) + dACorner;

				dAz = 0;
				dBz = 0;

				nCount = 1;

				do {

					dAz2 = (dAz * dAz) - (dBz * dBz) + dAc;
					dBz2 = 2 * dAz * dBz + dBc;

					dAz = dAz2;
					dBz = dBz2;

					dSize = dAz2 * dAz2 + dBz2 * dBz2;
					if (dSize > 4){
						break;
					}

					++nCount;

				} while (nCount <= nMaxIter);


				if (nCount >= nMaxIter)
				{
					// black -- inside the set
					Plot(pDC, nAcross, nDown, nPixelWidth, nPixelHeight, RGB(0,0,0));
				}
				else
				{
					// outside the set
					int c = ((float)nCount / nMaxIter) * 255;
					Plot(pDC, nAcross, nDown, nPixelWidth, nPixelHeight, RGB(c*.5,c*.5,c));
				}

				if (gStop){ return; }

			}
		}
	}

	pDC->DeleteDC();

}

void JuliaZoom(CWnd *pWnd, int x, int y)
{
	// zoom to the area clicked
	CRect rect;
	pWnd->GetClientRect(&rect);

	int nPortWidth = rect.Width();
	int nPortHeight = rect.Height();
	
	double fHOffset = gSide * (x / (double)nPortWidth);
	double fVOffset = gSide * (y / (double)nPortHeight);

	if (gZoomDir == 1)
	{
		// zoom in
		gSide /= gZoomFactor;
	} else {
		// zoom out
		gSide *= gZoomFactor;
	}	

	gACorner = gACorner + (fHOffset - (gSide / 2));
	gBCorner = gBCorner + (fVOffset - (gSide / 2));

	pWnd->Invalidate();
}


void Plot(CDC *pDC, int nX, int nY, UINT nPixelWidth, UINT nPixelHeight, COLORREF rgbColor)
{
	if ((nPixelWidth != 1) || (nPixelHeight != 1))
	{
		// draw a fat pixel
		RECT rect;
		rect.left = nX * nPixelWidth;
		rect.top = nY * nPixelHeight;
		rect.right = (rect.left) + nPixelWidth + 1;
		rect.bottom = (rect.top) + nPixelHeight + 1;

		int saveddc = pDC->SaveDC();
		CBrush brush(rgbColor);

		pDC->SelectObject(&brush);
		pDC->SelectObject(GetStockObject(NULL_PEN));

		pDC->Rectangle(&rect);

		pDC->RestoreDC(saveddc);

		brush.DeleteObject();
	}
	else
	{
		// draw a regular pixel
		pDC->SetPixel(nX, nY, rgbColor);
	}
}
