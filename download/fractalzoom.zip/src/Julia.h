#define FULLVIEW_ACORNER		(-2.0f)
#define FULLVIEW_BCORNER		(-1.245288f)
#define FULLVIEW_SIDE			(2.53866f)

extern double gACorner;
extern double gBCorner;
extern double gSide;

extern int gZoomFactor;
extern int gZoomDir;
extern BOOL gStop;

void JuliaRender(CWnd *pWnd, double dACorner, double dBCorner, double dSide);
void JuliaZoom(CWnd *pWnd, int x, int y);

