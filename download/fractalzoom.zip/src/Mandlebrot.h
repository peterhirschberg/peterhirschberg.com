// Mandlebrot.h : main header file for the MANDLEBROT application
//

#if !defined(AFX_MANDLEBROT_H__D1C44865_B635_11D3_BD2C_00A0CC4068FA__INCLUDED_)
#define AFX_MANDLEBROT_H__D1C44865_B635_11D3_BD2C_00A0CC4068FA__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CMandlebrotApp:
// See Mandlebrot.cpp for the implementation of this class
//

class CMandlebrotApp : public CWinApp
{
public:
	CMandlebrotApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMandlebrotApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

public:
	//{{AFX_MSG(CMandlebrotApp)
	afx_msg void OnAppAbout();
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MANDLEBROT_H__D1C44865_B635_11D3_BD2C_00A0CC4068FA__INCLUDED_)
