// ChildView.cpp : implementation of the CChildView class
//

#include "stdafx.h"
#include "Mandlebrot.h"
#include "ChildView.h"
#include "MainFrm.h"

#include "Julia.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


DWORD WINAPI RenderThreadProc(LPVOID pParam);


/////////////////////////////////////////////////////////////////////////////
// CChildView

CChildView::CChildView()
{
	m_hThread = NULL;
}

CChildView::~CChildView()
{
}


BEGIN_MESSAGE_MAP(CChildView,CWnd )
	//{{AFX_MSG_MAP(CChildView)
	ON_WM_PAINT()
	ON_WM_LBUTTONDOWN()
	ON_COMMAND(ID_ZOOM_FULLVIEW, OnZoomFullview)
	ON_COMMAND(ID_ZOOM_ZOOMIN, OnZoomZoomin)
	ON_COMMAND(ID_ZOOM_ZOOMOUT, OnZoomZoomout)
	ON_COMMAND(ID_ZOOM_ZOOMLEVEL2, OnZoomZoomlevel2)
	ON_COMMAND(ID_ZOOM_ZOOMLEVEL4, OnZoomZoomlevel4)
	ON_COMMAND(ID_ZOOM_ZOOMLEVEL8, OnZoomZoomlevel8)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CChildView message handlers

BOOL CChildView::PreCreateWindow(CREATESTRUCT& cs) 
{
	if (!CWnd::PreCreateWindow(cs))
		return FALSE;

	cs.dwExStyle |= WS_EX_CLIENTEDGE;
	cs.style &= ~WS_BORDER;
	cs.lpszClass = AfxRegisterWndClass(CS_HREDRAW|CS_VREDRAW|CS_DBLCLKS, 
		::LoadCursor(NULL, IDC_ARROW), HBRUSH(COLOR_WINDOW+1), NULL);

	return TRUE;
}

void CChildView::OnPaint() 
{
	CPaintDC dc(this); // device context for painting

	if (m_hThread)
	{
		// terminate active thread
		gStop = TRUE;
		TerminateThread(m_hThread, 0);
		CloseHandle(m_hThread);
		m_hThread=NULL;
	}

	// create new thread
	DWORD id;
	m_hThread = CreateThread(NULL, 0,RenderThreadProc, (LPVOID)this, 0, &id);

}


//
// main rendering thread
//
DWORD WINAPI RenderThreadProc(LPVOID pParam)
{
	CChildView *pThis = (CChildView *)pParam;

	JuliaRender(pThis, gACorner, gBCorner, gSide);

	pThis->m_hThread = NULL;
	return 0;
}


BOOL CChildView::DestroyWindow() 
{
	if (m_hThread)
	{
		// terminate active thread
		gStop = TRUE;
		TerminateThread(m_hThread,0);
		CloseHandle(m_hThread);
		m_hThread=NULL;
	}

	return CWnd ::DestroyWindow();
}


void CChildView::OnLButtonDown(UINT nFlags, CPoint point) 
{
	JuliaZoom(this, point.x, point.y);
	
	CWnd::OnLButtonDown(nFlags, point);
}

void CChildView::OnZoomFullview() 
{
	gACorner = FULLVIEW_ACORNER;
	gBCorner = FULLVIEW_BCORNER;
	gSide = FULLVIEW_SIDE;
	Invalidate();
}

void CChildView::OnZoomZoomin() 
{
	gZoomDir = 1;
	UpdateMenus();
}

void CChildView::OnZoomZoomout() 
{
	gZoomDir = -1;
	UpdateMenus();
}

void CChildView::OnZoomZoomlevel2() 
{
	gZoomFactor = 2;
	UpdateMenus();
}

void CChildView::OnZoomZoomlevel4() 
{
	gZoomFactor = 4;
	UpdateMenus();
}

void CChildView::OnZoomZoomlevel8() 
{
	gZoomFactor = 8;
	UpdateMenus();
}


void CChildView::UpdateMenus()
{
	CWnd *pWnd = AfxGetMainWnd();
	if (pWnd)
	{
		CMenu *pMenu = pWnd->GetMenu();
		if (pMenu)
		{
			CMenu *pSubMenu = pMenu->GetSubMenu(1);
			if (pSubMenu)
			{
				pSubMenu->CheckMenuItem(ID_ZOOM_ZOOMIN, MF_BYCOMMAND | (gZoomDir == 1) ? MF_CHECKED : MF_UNCHECKED);
				pSubMenu->CheckMenuItem(ID_ZOOM_ZOOMOUT, MF_BYCOMMAND | (gZoomDir != 1) ? MF_CHECKED : MF_UNCHECKED);

				pSubMenu->CheckMenuItem(ID_ZOOM_ZOOMLEVEL2, MF_BYCOMMAND | (gZoomFactor == 2) ? MF_CHECKED : MF_UNCHECKED);
				pSubMenu->CheckMenuItem(ID_ZOOM_ZOOMLEVEL4, MF_BYCOMMAND | (gZoomFactor == 4) ? MF_CHECKED : MF_UNCHECKED);
				pSubMenu->CheckMenuItem(ID_ZOOM_ZOOMLEVEL8, MF_BYCOMMAND | (gZoomFactor == 8) ? MF_CHECKED : MF_UNCHECKED);
			}
		}
	}
}

BOOL CChildView::Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext) 
{
	BOOL ret = CWnd::Create(lpszClassName, lpszWindowName, dwStyle, rect, pParentWnd, nID, pContext);
	if (ret)
	{
		UpdateMenus();
	}
	return ret;
}
