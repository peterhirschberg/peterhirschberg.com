Fractal Zoom
Copyright (C) 2002 Peter Hirschberg

peter@peterhirschberg.com
www.peterhirschberg.com
