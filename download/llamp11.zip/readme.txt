=========================================================
Taskbar LavaLamp
Version 1.1

Copyright � 1998 Peter Hirschberg
Email: peter@peterhirschberg.com
Website: http://www.peterhirschberg.com
=========================================================


1.0 CONTENTS
============
1.0 ..... CONTENTS
1.1 ..... DESCRIPTION
1.2 ..... INSTALLATION / SETUP
1.3 ..... LEGAL STUFF


1.1 DESCRIPTION
===============
Taskbar LavaLamp is a program that resides in your Windows system tray and simulates the oozing lava lamps of the 60's.


1.2 INSTALLATION / SETUP
========================
There are two files in the zip archive.
 - lavalamp.exe			The main executable file
 - readme.txt			This file

Double-click on the file "lavalamp.exe" to run the program.
A shortcut to the program may be placed in your Startup folder for automatic execution.


1.3 LEGAL STUFF
===============
You are free to distribute this program as long as:
 - it is not altered in any way
 - it is distributed with all the original associated files
 - no charge is made for the distribution

Contact me for commercial distribution or any other usage!




